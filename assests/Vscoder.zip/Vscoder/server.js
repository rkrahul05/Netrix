const express=require('express');
const app=express();
const server=require('http').Server(app); 

const io = require('socket.io')(server);
// export const excel=require('xlsx');
const { v4 : uuidv4 }= require('uuid');
const { ExpressPeerServer } = require('peer');
const peerServer = ExpressPeerServer(server,{
    debug: true
});
app.set('view engine','ejs');
app.use(express.static('public'));
app.use('/peerjs', peerServer);
// app.use('/XLSX',excel);
app.get('/',function(req,res){
    res.redirect(`/${uuidv4()}`); //it is using string literal
})

app.get('/:room',function(req,res){
    res.render('room',{roomId: req.params.room})
})
// app.get("/homework",function(req,res){
//     console.log("I am clicked");

// })
io.on('connection', socket =>{
    socket.on('join-room', (roomId, userId) =>{ 
        socket.join(roomId);
        socket.broadcast.to(roomId).emit('user-connected', userId);
        // reciving the message
        socket.on('message',message =>{
            io.to(roomId).emit('createMessage',message)
        })
        // marking attendance
        socket.on('attendance',attendance=>{
            io.to(roomId).emit('Sendattendance',attendance)
        })
        socket.on('Link',Link=>{
            io.to(roomId).emit('sendLink',Link)
        })

    })
})

server.listen(process.env.PORT||3030);