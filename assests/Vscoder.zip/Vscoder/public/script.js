//import { io } from "socket.io";

// const e = require("express");

//const { text } = require("express");

//const { PeerServer } = require("peer");

//const { peerServer } = require("peer");
const socket = io('/');

const videoGrid =document.getElementById('video-grid');
const myVideo = document.createElement('video');
myVideo.muted = true;
var peer =new Peer();
var peer = new Peer(undefined,{
    path: '/peerjs',
    host: '/',
    port: '443'
})

const data=[];
    
let myVideoStream;

navigator.mediaDevices.getUserMedia({
    video: true,
    audio: true
}).then(stream =>{
    myVideoStream = stream;
    console.log("myvedio",myVideoStream);
    addVideoStream(myVideo, stream);

    peer.on('call', call=>{
        call.answer(stream)
        const video= document.createElement('video')
        call.on('stream', userVideoStream=>{
            addVideoStream(video, userVideoStream)
        })
    })

    /*socket.on('user-connected', (userId)=>{
        connecToNewUser(userId ,stream);
    })*/
    socket.on("user-connected", (userId) => {
         connecToNewUser(userId, stream);
        console.log("userId:", userId); 
        setTimeout(function () {
          connecToNewUser(userId, stream);
        }, 1000);
      });
    

} )



peer.on('open', id =>{
    socket.emit('join-room', ROOM_ID,id);
})
   

const connecToNewUser=(userId, stream)=>{
    console.log("New user");
    const call = peer.call(userId,stream)
    const video = document.createElement('video')
    call.on('stream', userVideoStream =>{
        addVideoStream(video, userVideoStream)
    })
}

//This is going to be so much fun
//I had switeched of the window defender
//Now i also turned off the antivirus and defender
// The client side is also not woking
//The whole chaos was created by broadcast statement. 
const addVideoStream = (video, stream) =>{
    video.srcObject = stream;
    console.log("addVideoStream", video.srcObject)
    video.addEventListener('loadedmetadata', () =>{
        video.play();
    })
    videoGrid.append(video);
}
// No change is required
//Message functionality
let text =$('input')

$('html').keydown((e)=>{
    if(e.which==13 && text.val().length!==0){
        console.log(text.val());
        socket.emit('message',text.val());
        text.val('')
    }
});

// reciving the message from server
socket.on('createMessage', message =>{
    $('.messages').append(`<li class="message"><b>user</b><br/>${message}</li>`);
    //Correcting the scrolling problem
    scrollToBottom();//defination of function is below
})

const scrollToBottom= () =>{
    let d= $('.main__chat_window');
    d.scrollTop(d.prop("scrollHeight"))
}

//Mute the video
const muteUnmute= ()=>{
    const enabled =myVideoStream.getAudioTracks()[0].enabled;
    if(enabled){
        myVideoStream.getAudioTracks()[0].enabled=false;
        setUnmuteButton();
    }else{
        setMuteButton();
        myVideoStream.getAudioTracks()[0].enabled=true;
    }
}

const setMuteButton = () => {
    const html = `
      <i class="fas fa-microphone"></i>
      <span>Mute</span>
    `
    document.querySelector('.main__mute_button').innerHTML = html;
}
  
const setUnmuteButton = () => {
    const html = `
      <i class="unmute fas fa-microphone-slash"></i>
      <span>Unmute</span>
    `
    document.querySelector('.main__mute_button').innerHTML = html;
}

  //Stop the video. It is almost the same

const playStop = () => {
    let enabled = myVideoStream.getVideoTracks()[0].enabled;
    if (enabled) {
      myVideoStream.getVideoTracks()[0].enabled = false;
      setPlayVideo()
    } else {
      setStopVideo()
      myVideoStream.getVideoTracks()[0].enabled = true;
    }
}

const setStopVideo = () => {
    const html = `
      <i class="fas fa-video"></i>
      <span>Stop Video</span>
    `
    document.querySelector('.main__video_button').innerHTML = html;
}
  
const setPlayVideo = () => {
    const html = `
    <i class="stop fas fa-video-slash"></i>
      <span>Play Video</span>
    `
    document.querySelector('.main__video_button').innerHTML = html;
}

const MarkAttendance= ()=>{
    let atndnc=document.getElementById("user_name").value
   // console.log("value",atndnc);
    let obj={};
    obj.name=atndnc;
    obj.date=getDate();
    socket.emit('attendance',obj);
    document.getElementById("user_name").value="";
    socket.on('Sendattendance',attendance=>{
    data.push(attendance);
    console.log("server",data);
    });
    
}
const Link= ()=>{
    let formLink=document.getElementById("link").value
   // console.log("value",atndnc);
    let obj={};
    obj.name=atndnc;
    obj.date=getDate();
    socket.emit('Link',formLink);
    document.getElementById("home_work").value=formLink;
    
}
const  getDate=()=>
  {
    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    return date;
}
var link;
function attach(){
    var data=prompt("Enter the link here");
    link=data;
    //console.log(link);
}
function uploadHW(){
console.log("T am linking the form with button");
var toLink=String(link);
if (window.confirm('If you click "ok" you would be redirected . Cancel will load this website ')) 
{
window.location.href=toLink;
};
}
function exportDownlaod() {  
var displayData = data.reduce((unique, o) => {
    if(!unique.some(obj => obj.name === o.name)) {
      unique.push(o);
    }
    return unique;
},[]);
  alert(JSON.stringify(displayData)+"\n");
}





  